import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { existsSync, readFileSync, writeFileSync } from 'fs';
import { join } from 'path';

console.log('[Firestore] Initializing pure Firebase Admin SDK...');

// Determine config path
const configPath = join(process.cwd(), 'firebase-applet-config.json');
let firebaseConfig: any = {};
if (existsSync(configPath)) {
  try {
    firebaseConfig = JSON.parse(readFileSync(configPath, 'utf8'));
    console.log('[Firestore] Loaded firebase-applet-config.json successfully.');
  } catch (err: any) {
    console.error('[Firestore] Error reading firebase-applet-config.json:', err.message);
  }
}

const projectId = firebaseConfig.projectId || process.env.FIREBASE_PROJECT_ID;
const databaseId = firebaseConfig.firestoreDatabaseId || process.env.FIRESTORE_DATABASE_ID || '(default)';

let adminApp: any;
try {
  const apps = getApps();
  if (apps.length > 0) {
    adminApp = apps[0];
  } else {
    const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT;
    const configOpts: any = {
      projectId: projectId || undefined,
    };

    if (serviceAccountJson) {
      try {
        const credential = JSON.parse(serviceAccountJson);
        configOpts.credential = cert(credential);
        console.log('[Firestore] Initializing with FIREBASE_SERVICE_ACCOUNT creds.');
      } catch (e: any) {
        console.error('[Firestore] FIREBASE_SERVICE_ACCOUNT parsing error:', e.message);
      }
    } else {
      console.log('[Firestore] Falling back to Default Application Credentials (ADC) / Ambient credentials.');
    }
    adminApp = initializeApp(configOpts);
  }
} catch (err: any) {
  console.warn('[Firestore App Init Warning]:', err.message);
}

// Instantiate genuine client
let rawDb: any;
try {
  rawDb = getFirestore(adminApp, databaseId);
  console.log(`[Firestore] Connected to Firebase Project "${projectId}", DB "${databaseId}".`);
} catch (err: any) {
  console.error('[Firestore Client Init Fatal]:', err.message);
}

// -----------------------------------------------------
// Dual Engine Fallback implementation
// -----------------------------------------------------

const LOCAL_DB_FILE = join(process.cwd(), 'database_local_firestore.json');

// Initialize local DB structures if not present
function loadLocalDb(): Record<string, Record<string, any>> {
  if (!existsSync(LOCAL_DB_FILE)) {
    const defaultData = {
      packages: {
        'plan-basic': {
          name: 'Basic',
          speed: 10,
          price: 500.00,
          fup_limit: 'Unlimited',
          fupLimit: 'Unlimited',
          mikrotik_profile: '10M_Unlimited',
          mikrotikProfile: '10M_Unlimited',
          description: 'Basic broadband plan for light browsing.',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        'plan-standard': {
          name: 'Standard',
          speed: 20,
          price: 800.00,
          fup_limit: 'Unlimited',
          fupLimit: 'Unlimited',
          mikrotik_profile: '20M_Unlimited',
          mikrotikProfile: '20M_Unlimited',
          description: 'Standard household plan for streaming.',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        'plan-premium': {
          name: 'Premium',
          speed: 50,
          price: 1200.00,
          fup_limit: 'Unlimited',
          fupLimit: 'Unlimited',
          mikrotik_profile: '50M_Unlimited',
          mikrotikProfile: '50M_Unlimited',
          description: 'Premium ultra-fast broadband service.',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      },
      users: {
        'user-admin': {
          username: 'admin',
          password: '$2b$10$vUWuw9BwwPEGd5btDBEkK.jXwuWtpLaWqpgo41GjOhkjV.7QdAITi', // admin123 hash
          name: 'System Admin',
          phone: '01700000000',
          address: 'HQ Dhaka',
          role: 'admin',
          status: 'Active',
          package_id: null,
          ip_address: '10.0.0.1',
          mac_address: '00:11:22:33:44:55',
          pppoe_username: 'admin_ppp',
          total_due: 0.00,
          expiry_date: '',
          created_at: new Date().toISOString(),
          createdAt: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }
      },
      bills: {},
      payments: {},
      tickets: {},
      ticket_replies: {}
    };
    writeFileSync(LOCAL_DB_FILE, JSON.stringify(defaultData, null, 2), 'utf8');
    return defaultData;
  }

  try {
    return JSON.parse(readFileSync(LOCAL_DB_FILE, 'utf8'));
  } catch (err) {
    console.error('[Fallback Engine] Read error. Resetting JSON file:', err);
    return {};
  }
}

function saveLocalDb(data: Record<string, Record<string, any>>) {
  try {
    writeFileSync(LOCAL_DB_FILE, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error('[Fallback Engine] Write error:', err);
  }
}

// Local mock classes executing standard Firestore patterns
class LocalDocSnapshot {
  id: string;
  exists: boolean;
  private _data: any;

  constructor(id: string, exists: boolean, data: any) {
    this.id = id;
    this.exists = exists;
    this._data = data;
  }

  data() {
    return this._data ? { ...this._data } : undefined;
  }
}

class LocalQuerySnapshot {
  docs: LocalDocSnapshot[];
  empty: boolean;

  constructor(docs: LocalDocSnapshot[]) {
    this.docs = docs;
    this.empty = docs.length === 0;
  }

  forEach(callback: (doc: LocalDocSnapshot) => void) {
    this.docs.forEach(callback);
  }
}

class LocalDocReference {
  id: string;
  private collectionName: string;

  constructor(id: string, collectionName: string) {
    this.id = id;
    this.collectionName = collectionName;
  }

  async get(): Promise<LocalDocSnapshot> {
    const dbData = loadLocalDb();
    const collection = dbData[this.collectionName] || {};
    const docData = collection[this.id];
    return new LocalDocSnapshot(this.id, !!docData, docData);
  }

  async set(data: any): Promise<void> {
    const dbData = loadLocalDb();
    if (!dbData[this.collectionName]) dbData[this.collectionName] = {};
    dbData[this.collectionName][this.id] = { ...data };
    saveLocalDb(dbData);
  }

  async update(data: any): Promise<void> {
    const dbData = loadLocalDb();
    if (!dbData[this.collectionName]) dbData[this.collectionName] = {};
    const existing = dbData[this.collectionName][this.id] || {};
    dbData[this.collectionName][this.id] = { ...existing, ...data };
    saveLocalDb(dbData);
  }

  async delete(): Promise<void> {
    const dbData = loadLocalDb();
    if (dbData[this.collectionName]) {
      delete dbData[this.collectionName][this.id];
      saveLocalDb(dbData);
    }
  }
}

class LocalQuery {
  private collectionName: string;
  private filters: Array<{ field: string; op: string; val: any }> = [];
  private limitNumber?: number;

  constructor(collectionName: string, filters: Array<{ field: string; op: string; val: any }> = [], limitNumber?: number) {
    this.collectionName = collectionName;
    this.filters = filters;
    this.limitNumber = limitNumber;
  }

  where(field: string, op: string, val: any): LocalQuery {
    return new LocalQuery(this.collectionName, [...this.filters, { field, op, val }], this.limitNumber);
  }

  limit(n: number): LocalQuery {
    return new LocalQuery(this.collectionName, this.filters, n);
  }

  count() {
    return {
      get: async () => {
        const snap = await this.get();
        return {
          data: () => ({
            count: snap.docs.length
          })
        };
      }
    };
  }

  async get(): Promise<LocalQuerySnapshot> {
    const dbData = loadLocalDb();
    const collectionData = dbData[this.collectionName] || {};
    let matched: LocalDocSnapshot[] = [];

    for (const [id, data] of Object.entries(collectionData)) {
      let match = true;
      for (const filter of this.filters) {
        const docVal = data[filter.field];
        if (filter.op === '==') {
          if (docVal !== filter.val) {
            match = false;
            break;
          }
        }
      }
      if (match) {
        matched.push(new LocalDocSnapshot(id, true, data));
      }
    }

    if (this.limitNumber !== undefined) {
      matched = matched.slice(0, this.limitNumber);
    }

    return new LocalQuerySnapshot(matched);
  }
}

class LocalCollectionReference extends LocalQuery {
  private _name: string;

  constructor(name: string) {
    super(name);
    this._name = name;
  }

  doc(id?: string): LocalDocReference {
    const finalId = id || 'doc-' + Math.random().toString(36).substring(2, 11);
    return new LocalDocReference(finalId, this._name);
  }

  async add(data: any): Promise<LocalDocReference> {
    const generatedId = 'doc-' + Math.random().toString(36).substring(2, 11);
    const docRef = this.doc(generatedId);
    await docRef.set(data);
    return docRef;
  }
}

class FallbackDatabaseEngine {
  collection(name: string): LocalCollectionReference {
    return new LocalCollectionReference(name);
  }
}

// Global engine selector state
let useFallbackEngine = false;

// Proxy database delegating requests transparently
const dbProxy = {
  collection(name: string) {
    if (useFallbackEngine) {
      return (new FallbackDatabaseEngine()).collection(name);
    }
    
    // Attempt Admin SDK delegation, catch exceptions dynamically
    try {
      const colRef = rawDb.collection(name);
      
      // Wrap methods to detect queries throwing 7 PERMISSION_DENIED
      const wrapQuery = (queryObj: any): any => {
        return {
          where(field: string, op: string, val: any) {
            return wrapQuery(queryObj.where(field, op, val));
          },
          limit(n: number) {
            return wrapQuery(queryObj.limit(n));
          },
          count() {
            return {
              async get() {
                try {
                  return await queryObj.count().get();
                } catch (error: any) {
                  if (error.message && error.message.includes('PERMISSION_DENIED')) {
                    console.warn('[Engine Fallback] Count check PERMISSION_DENIED. Switching immediately to fallback engine...');
                    useFallbackEngine = true;
                    return (new FallbackDatabaseEngine()).collection(name).count().get();
                  }
                  throw error;
                }
              }
            };
          },
          async get() {
            try {
              return await queryObj.get();
            } catch (error: any) {
              if (error.message && error.message.includes('PERMISSION_DENIED')) {
                console.warn('[Engine Fallback] Query read PERMISSION_DENIED. Switching immediately to fallback engine...');
                useFallbackEngine = true;
                return await (new FallbackDatabaseEngine()).collection(name).get();
              }
              throw error;
            }
          }
        };
      };

      return {
        ...colRef,
        doc(id?: string) {
          const docRef = colRef.doc(id);
          return {
            ...docRef,
            async get() {
              try {
                return await docRef.get();
              } catch (error: any) {
                if (error.message && error.message.includes('PERMISSION_DENIED')) {
                  console.warn('[Engine Fallback] Document read PERMISSION_DENIED. Switching to fallback...');
                  useFallbackEngine = true;
                  return await (new FallbackDatabaseEngine()).collection(name).doc(id).get();
                }
                throw error;
              }
            },
            async set(data: any) {
              try {
                return await docRef.set(data);
              } catch (error: any) {
                if (error.message && error.message.includes('PERMISSION_DENIED')) {
                  console.warn('[Engine Fallback] Document write PERMISSION_DENIED. Switching to fallback...');
                  useFallbackEngine = true;
                  return await (new FallbackDatabaseEngine()).collection(name).doc(id).set(data);
                }
                throw error;
              }
            },
            async update(data: any) {
              try {
                return await docRef.update(data);
              } catch (error: any) {
                if (error.message && error.message.includes('PERMISSION_DENIED')) {
                  console.warn('[Engine Fallback] Document update PERMISSION_DENIED. Switching to fallback...');
                  useFallbackEngine = true;
                  return await (new FallbackDatabaseEngine()).collection(name).doc(id).update(data);
                }
                throw error;
              }
            },
            async delete() {
              try {
                return await docRef.delete();
              } catch (error: any) {
                if (error.message && error.message.includes('PERMISSION_DENIED')) {
                  console.warn('[Engine Fallback] Document delete PERMISSION_DENIED. Switching to fallback...');
                  useFallbackEngine = true;
                  return await (new FallbackDatabaseEngine()).collection(name).doc(id).delete();
                }
                throw error;
              }
            }
          };
        },
        async add(data: any) {
          try {
            return await colRef.add(data);
          } catch (error: any) {
            if (error.message && error.message.includes('PERMISSION_DENIED')) {
              console.warn('[Engine Fallback] Document add PERMISSION_DENIED. Switching to fallback...');
              useFallbackEngine = true;
              return await (new FallbackDatabaseEngine()).collection(name).add(data);
            }
            throw error;
          }
        },
        where(field: string, op: string, val: any) {
          return wrapQuery(colRef.where(field, op, val));
        },
        limit(n: number) {
          return wrapQuery(colRef.limit(n));
        },
        count() {
          return wrapQuery(colRef).count();
        },
        async get() {
          try {
            return await colRef.get();
          } catch (error: any) {
            if (error.message && error.message.includes('PERMISSION_DENIED')) {
              console.warn('[Engine Fallback] Collection get PERMISSION_DENIED. Switching to fallback...');
              useFallbackEngine = true;
              return await (new FallbackDatabaseEngine()).collection(name).get();
            }
            throw error;
          }
        }
      };

    } catch (err: any) {
      console.warn('[Engine Fallback] Fallback triggered automatically due to connection failure:', err.message);
      useFallbackEngine = true;
      return (new FallbackDatabaseEngine()).collection(name);
    }
  }
};

// Fire asynchronous diagnostic to determine fallback configuration active
(async () => {
  try {
    if (rawDb) {
      await rawDb.collection('users').limit(1).get();
      console.log('[Firestore] Core Google-Cloud Native administrative SDK verified successfully!');
    } else {
      useFallbackEngine = true;
      console.log('[Firestore] Raw DB undefined, activating Fallback Engine.');
    }
  } catch (err: any) {
    if (err.message && err.message.includes('PERMISSION_DENIED')) {
      console.log('[Firestore] Sandboxed service account permissions restricted; active transparent Fallback Persistent Engine enabled.');
      useFallbackEngine = true;
    } else {
      console.error('[Firestore] Initialization diagnostic exception:', err.message);
    }
  }
})();

export { dbProxy as db };
export { useFallbackEngine };
export const realFirestoreDb = rawDb;
